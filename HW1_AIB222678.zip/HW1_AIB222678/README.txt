--------------------------------------------COL761 Assignment #1-----------------------------------------
Problem Statement  : Implement Apriori and FP-Tree Algorithm to mine frequent itemsets . Apply it on 
the Dataset: http://fimi.uantwerpen.be/data/webdocs.dat.gz.
You may assume all items are integers.

Team: CORE

Team Members: Sangam Kumar 2022AIB2671
		   Swaransh Patel 2022AIB2678
		   Khushal Shakya 2022AIB2683


File Submitted:
1.	Apriori.py : This file has the implementation of the apriori algorithm to extract frequent item 
sets. Initially it scans the database to generate the first candidate set and calculate the frequent 
item set from the generated candidate set .After that it will prune the item set which having 
frequency less than min support and the process continues until no frequent item sets are 
generated.

2.	FP-Tree.py : The code takes as arguments the input file, minimum support and the output file 
name and runs the FP-Tree algorithm on the dataset provided in the input file. It calculate the 
frequency of the each item set in the first scan and in the second scan create the header table 
based on which we create the FP-Tree. Then, recursively traversing the order the header table in 
decreasing order of the frequency list, the tree is updated and the element is added to the frequent 
item set if it�s support crosses the threshold.

3.	common.py: This file calls the apriori.py and FP-Tree.py to run both the file simultaneously if 
we want the plot graph.

4.	AIB222678.sh: This is the bash file which execute the following command �./AIB222678.sh �
apriori <dataset_name> Support <outputfilename>� , �./AIB222678.sh �fptree <dataset_name> 
Support <outputfilename>� , and �./AIB222678.sh �plot <dataset_name>  <outputfilename>� .

5.	Plotting Data: Python file �plot.py� has been used for plotting the execution time graphs and 
comparing the two algorithms. We use the function for plotting name as matplotlib.

----------------------------------------------EXPLANATION---------------------------------------------------

After observing the running plots, we can easily see that the time of FP-Tree is lesser than the running 
time of Apriori algorithm. Also with the increase in the threshold support FP-Tree is taking less time 
Hence we can say that FP-Tree performs better than Apriori Algorithm. 
In Apriori, the to generate the candidate set it needs to scan the database again and again . Hence for that 
it requires more amount of computational collection. That�s why it is slower.
In FP-Tree there is no need to generate the candidate sets for each different collection of item sets. This 
reduce the number of times to scan the database for generating the item sets. In FP-Tree we are scanning 
the data base only two times. So it require less memory space and reduce the high computational 
calculation.

----------------------------------------------CONTRIBUTIONS--------------------------------------------------

1.	Sangam Kumar AIB222671 (33.33%)
Implement the algorithm of FP-Tree and write the Readme.txt, bash file, plot.py with Khushal 
Shakya 

2.	Swaransh Patel AIB222678 (33.33%)
Implement the algorithm of Apriori, create the common.py file and submit the assignmet on 
moodle and github repository

3.	Khushal Shakya AIB222683 (33.33%)
Implement the algorithm of FP-Tree and write the Readme.txt, bash file, plot.py with Sangam 
Kumar
