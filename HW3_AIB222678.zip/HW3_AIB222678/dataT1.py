# -*- coding: utf-8 -*-
# print(torch.__version__)

# !pip install  torch_geometric
# !pip install torch_sparse
# !pip install torch_scatter
# !pip install torch


# !pip install torch-scatter -f https://data.pyg.org/whl/torch-1.12.1+cu113.html
# !pip install torch-sparse -f https://data.pyg.org/whl/torch-1.12.1+cu113.html
# !pip install torch-cluster -f https://data.pyg.org/whl/torch-1.12.1+cu113.html
# !pip install git+https://github.com/pyg-team/pytorch_geometric.git


import torch
import torch,numpy as np
from torch_geometric.utils import dense_to_sparse
from torch_geometric.data import Data,DataLoader,Dataset
from torch_geometric.nn import GCNConv,SAGEConv,GATv2Conv
from torch_geometric.nn.models import GCN
import pandas as pd
from torch import nn
import torch.nn.functional as F
import warnings
warnings.filterwarnings("ignore")
import sys,os
crrdir=os.curdir

path_to_train=None
path_to_adj_mx=None
path_to_graph=None
path_to_test=None
path_to_out=None
path_to_modal=None

if sys.argv[1]=='train':
  path_to_data=sys.argv[2]
  path_to_adj_mx=sys.argv[3]
  path_to_graph=sys.argv[4]
else:
  path_to_data=sys.argv[2]
  path_to_out=sys.argv[3]
  path_to_modal=sys.argv[4]
  
if path_to_adj_mx is None:
  path_to_adj_mx=open('paths_adj.txt','r').read()
else:
  open('paths_adj.txt','w').write(str(path_to_adj_mx))

class mydata(Dataset):
  def __init__(self,X,edge_index,graph_splits,node_id):
     super().__init__()
     self.X=X
     self.edge_index=edge_index
     self.train_mask,self.test_mask,self.val_mask=mask(graph_splits,node_id)

  def len(self):
        return self.X.shape[0]-1
  def get(self,idx):
      x,y = torch.tensor(self.X[idx,:],dtype=torch.float).reshape(-1,1),torch.tensor(self.X[idx+1,:],dtype=torch.float).reshape(-1,1)
      data = Data(x = x, edge_index = self.edge_index, y = y)
      data.train_mask = self.train_mask
      data.test_mask = self.test_mask
      data.val_mask = self.val_mask
      return data
    
class mydata2(Dataset):
  def __init__(self,X,edge_index):
     super().__init__()
     self.X=X
     self.edge_index=edge_index
  def len(self):
        return self.X.shape[0]
  def get(self,idx):
      x,y = torch.tensor(self.X[idx,:],dtype=torch.float).reshape(-1,1),torch.tensor(self.X[idx,:],dtype=torch.float).reshape(-1,1)
      data = Data(x = x, edge_index = self.edge_index, y = y)
      return data

def mask(d,ids):
  train_id=d['train_node_ids']
  test_id=d['test_node_ids']
  val_id=d['val_node_ids']
  node_dict={int(id):idx for idx,id in enumerate(ids)}

  trn = torch.zeros(len(ids), dtype=bool)
  tet = torch.zeros(len(ids), dtype=bool)
  val = torch.zeros(len(ids), dtype=bool)
  for i in train_id :
    trn[node_dict[i]]=True 

  for i in test_id :
    tet[node_dict[i]]=True 
 

  for i in val_id :
    val[node_dict[i]]=True 
    trn[node_dict[i]]=True 


  return trn,tet,val

class gnnMod(nn.Module):
    def __init__(self,n_features,n_target):
        super().__init__()
        self.gcn=GCN(in_channels=n_features, hidden_channels=32, num_layers=3, out_channels=n_target)
    def forward(self,x):
        h=self.gcn(x.x,x.edge_index)
        h=F.relu(h)
        return h

class gnnModsage(nn.Module):
    def __init__(self,n_features,n_target):
        super().__init__()
        self.conv1 = SAGEConv(n_features, 64, 'mean')
        self.conv2 = SAGEConv(64, 32, 'mean')
        self.linear = torch.nn.Linear(32,n_target)

    def forward(self, data):
        x, edge_index, edge_weight = data.x, data.edge_index, data.edge_weight
        x = F.relu(self.conv1(x, edge_index))
        x = F.relu(self.conv2(x, edge_index))
        x = self.linear(x)
        return x
def test_loop(dataloader, model,test_loss = 0):
    with torch.no_grad():
        model.eval()
        for data in dataloader.dataset:
            pred = model(data)
            los=torch.abs(pred[data.test_mask] - data.y[data.test_mask])
            test_loss += torch.mean(los).item() #MAE
            a=test_loss/len(dataloader.dataset)
    print(f"Test Error: \n\tAvg MAE: {a:>8f} \n\n")
    return float(a)
  
  
  
# def test_loop(dataloader, model,test_loss = 0):
#     with torch.no_grad():
#         model.eval()
#         f=open('output_file.csv','w')
#         for data in dataloader.dataset:
#             pred = model(data)
#             f.write(str(pred))
#         f.close()
    # print(f"Test Error: \n\tAvg MAE: {a:>8f} \n\n")
def train():
  best_mae=100000.0
  device = (torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu"))
  A=torch.Tensor(pd.read_csv(path_to_adj_mx).to_numpy()[:,1:])
  X=pd.read_csv(path_to_data)
  graph_splits = np.load(path_to_graph)
  node_id=list(X)[1:]
  #train_mask,test_mask,val_mask=mask(graph_splits,node_id)
  X=X.to_numpy()[:,1:].astype(float)
  edge_indx,edge_w=dense_to_sparse(A)
  dataset=mydata(X,edge_indx,graph_splits,node_id)
  dataloader = DataLoader(dataset, batch_size=32, shuffle=False)
  # return A,X,edge_indx,dataloader
  # Create model and optimizers
  model=gnnModsage(1,1)
  optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
  for epoch in range(20): 
      loss = 0
      step = 0
      size=(dataloader.dataset)
      # print(size)
      for data in dataloader:
        # print(data)
        model.train()
        y_pred = model(data)
        # print(data.train_mask)
        loss = F.mse_loss(y_pred[data.train_mask], data.y[data.train_mask]) 
        step += 1
      loss = loss / (step + 1)
      loss.backward()
      optimizer.step()
      optimizer.zero_grad()
      print("Epoch {} \n\t train MSE: {:.4f}".format(epoch, loss.item()))
      mae=test_loop(dataloader,model)
      if mae<best_mae:
        best_mae=mae
        torch.save(model,crrdir+'/aib222678_task1.model')
def test():
  device = (torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu"))
  A=torch.Tensor(pd.read_csv(path_to_adj_mx).to_numpy()[:,1:])
  X=pd.read_csv(path_to_data)
  X=X.to_numpy()[:,1:].astype(float)
  edge_indx,edge_w=dense_to_sparse(A)
  dataset=mydata2(X,edge_indx)
  dataloader = DataLoader(dataset, batch_size=32, shuffle=False)
  model = torch.load(path_to_modal)
  model.eval()
  print(model)
  f=open(path_to_out+'output_file.csv','w')  
  for data in dataloader.dataset:
      pred = model(data)
      li=pred.T.detach().numpy()[0]

      # for d in pred:
      #   print(d)
      for i,l in enumerate(li):
        if i==len(li)-1:
          f.write(str(l))
        else:
          f.write(str(l)+',')
      f.write('\n')
  #pred=model(dataset)
  
  
  f.close()
 
 
 
if sys.argv[1]=='train':
  train()
else:
  test()
  
  
      

