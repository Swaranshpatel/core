from apriori import apriori
from fp import freq_pattern
import sys
import matplotlib.pyplot as plt
import timeit
# program_name=sys.argv[0]
input_file=sys.argv[2]
per_support=sys.argv[3]
program_call=sys.argv[1]


def ploting():
    output_file=sys.argv[3]
    req_support=[90,50,25,10,5]
    time_ap=[]
    time_fp=[]
    for st in req_support:
        s = timeit.default_timer()
        apriori(input_file,st,'out_ap'+str(st)+'_')
        e = timeit.default_timer()
        time_ap.append(e-s)

        s = timeit.default_timer()
        freq_pattern(input_file,st,'out_fp'+str(st)+'_')
        e = timeit.default_timer()
        time_fp.append(e-s)

    plt.plot(req_support,time_ap,'r',req_support,time_fp,'b')
    plt.xlabel('Support Thresholds (in percentage)')
    plt.ylabel('Running time (in seconds)')
    plt.legend(['Apriori','FP-tree'])
    plt.savefig('running_times_comp.png')

if program_call=='-apriori':
    output_file=sys.argv[4]
    per_support=int(per_support)
    apriori(input_file,per_support,output_file)
if program_call=='-fptree':
    output_file=sys.argv[4]
    per_support=int(per_support)
    freq_pattern(input_file,per_support,output_file)
if program_call=='-plot':
    ploting()
