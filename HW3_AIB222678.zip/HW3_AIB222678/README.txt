--------------------------------------------COL761 Assignment #3-----------------------------------------
File Submitted:
1. aib222678_task1.sh
2. aib222678_task2.sh
3. dataT1.py
4. dataT2.py

Models Submitted:
1.d1_aib222678_task1.model 
2.d2_aib222678_task1.model 
3.d1_aib222678_task2.model
4.d2_aib222678_task2.model 


Team: CORE

Team Members: Sangam Kumar 2022AIB2671
	      Swaransh Patel 2022AIB2678
		Khushal Shakya 2022AIB2683


Instructions to excecute code:
1. aib222678_task1.sh :
 command to run the train code: bash aib222678_task1.sh train /path/to/train.csv /path/to
 /adj_mx.csv /path/to/graph_splits.npz
 command to run the test code: bash aib222678_task1.sh test /path/to/test.csv /path/to
 /output_file.csv /path/to/task1.model


2. aib222678_task2.sh :
 command to run the train code: bash aiz218322_task2.sh train p f /path/to/train.csv /path/to
/adj_mx.csv /path/to/graph_splits.npz
 command to run the test code: bash aiz218322_task2.sh test p f /path/to/test.npz /path/to
/output_file.npz /path/to/task2.model




----------------------------------------------CONTRIBUTIONS--------------------------------------------------

1.	Sangam Kumar AIB222671 (33.33%)
2.	Swaransh Patel AIB222678 (33.33%)
3.	Khushal Shakya AIB222683 (33.33%)
Each Team member works in equal proportion.

