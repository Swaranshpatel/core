def freq_pattern(file_name,x,out_name):
    from itertools import islice
    import math
    class node:
        def __init__(self, elmt, elmt_count=0, upr_nd=None, link=None):
            self.elmt=elmt
            self.elmt_count=elmt_count
            self.upr_nd=upr_nd
            self.link=link
            self.lwr_nd={}
            
    class fptree:
        def __init__(self, data, spt=5,flag=None):
            self.root= node(elmt="Null", elmt_count=1)
            self.val,self.spt,self.elmtlinesort,self.nodetable,self.elmtsortdic,self.elmtdic,self.elmtorderdic=data,spt,[],[],[],{},{}
            self.flag=flag
            self.make(data)  

        def prun(self,wd_list):
            for i in wd_list:
                if(self.elmtdic[i]<self.spt):
                    del self.elmtdic[i]

        def helper(self):
            t=min(0,1)
            for i in self.elmtsortdic:
                w ,wc= i[0],i[1]
                self.elmtorderdic[w]=t
                w_info,t = dict(),t+1
                w_info['elmtn'],w_info['elmtcc'],w_info['linknode']=w,wc,None
                self.nodetable.append(w_info)
            # return w,wc,w_info
        def update(self,sortsupelmt,wd_list):
            if sortsupelmt:
                    sortsupelmt.sort(key= lambda k: self.elmtorderdic[k])
                    # sortsupelmt = sorted(supelmt, key = lambda k: self.elmtorderdic[k])
                    # sortsupelmt=supelmt
                    self.elmtlinesort+=sortsupelmt
                    #enter the elmt one by one from begining
                    nd = self.root
                # print(sortsupelmt)
                    for i in sortsupelmt:                  
                        if i in nd.lwr_nd:
                            nd.lwr_nd[i].elmt_count =nd.lwr_nd[i].elmt_count+1
                            nd=nd.lwr_nd[i]
                        else:
                            new_node= node(elmt=i,elmt_count=1,upr_nd=nd,link=None)
                            nd.lwr_nd[i] = new_node
                            nd=new_node
                            # link this node to nodetable
                            for elmtinfo in self.nodetable:
                                if elmtinfo["elmtn"] != nd.elmt:
                                    continue
                                else:
                                    if elmtinfo["linknode"] is not None:
                                        iter_node = elmtinfo["linknode"]
                                        while(iter_node.link != None):
                                            iter_node = iter_node.link
                                        iter_node.link = nd
                                    else:
                                        elmtinfo["linknode"] = nd

        def make(self, data):
            if self.flag:
                self.frq_count1(data) #cnt feq
                data=open(file_name)
            else:
                self.frq_count0(data)
            
            wd_list = list(self.elmtdic)

            self.prun(wd_list) #prn ele less then spt

            #sort the remaing items des, with first elmt count than work#id        

            self.elmtsortdic = sorted(self.elmtdic.items(), key=lambda x: (-x[1],x[0])) 

            #create a table containing elmt, elmtcount and all link node of that elmt
            
            self.helper()

            #make fptree line by line
            if self.flag:
                line=list(map(int,data.readline().split()))
                while line:
                    supelmt=[]
                    for k in line:
                        if k in self.elmtdic:
                            supelmt.append(k)
                    self.update(supelmt,wd_list)
                    line=list(map(int,data.readline().split()))
            else:
                for line in data:
                    supelmt=[]
                    for k in line:
                        if k in self.elmtdic:
                            supelmt.append(k)
                    self.update(supelmt,wd_list)


        #count frq 
        def frq_count1(self,data) :
            t=list(map(int,data.readline().split()))
            while t:
                for i in t:
                    if i in self.elmtdic:
                        self.elmtdic[i]+=1
                    else:
                        self.elmtdic[i]=1  
                t=list(map(int,data.readline().split()))       
            data.close()
        def frq_count0(self,data) :

            for  t in data:
                for i in t:
                    if i in self.elmtdic:
                        self.elmtdic[i]+=1
                    else:
                        self.elmtdic[i]=1  

    # create transactions for conditinal tree   
        def cPt(self,nd):

            if nd.upr_nd == None:
                return None
            
            ct_line =list()
            #starting from the leaf node reverse add elmt till hit root
            while nd != None:
                line=list()
                prnt = nd.upr_nd
                while prnt.upr_nd != None:
                    line+=[prnt.elmt]
                    prnt=prnt.upr_nd
                #reverse order the transaction
                line = line[::-1]
                for i in range(nd.elmt_count):
                    ct_line+=[line]
                #move on to next linknode
                nd=nd.link
            return ct_line
        
    #Find frequent elmt list by creating conditional tree
        def findfqt(self,upr_ndnode=None):
            if not len(list(self.root.lwr_nd)):
                return None
            sup,ans=self.spt,[]
            #starting from the end of nodetable
            rev_table = reversed(self.nodetable)
            for n in rev_table:
                fqset=[set(),0]

                if(upr_ndnode is not None):  
                    fqset[0] = {n['elmtn']}.union(upr_ndnode[0])    
                else:
                    # fqset[0] = {n['elmtn']}.union(upr_ndnode[0])
                    fqset[0]={n['elmtn'],}

                fqset[1]=n['elmtcc']
                ans.append(fqset)
                cond_tran = self.cPt(n['linknode'])
                #recursively build the conditinal fp tree
                con_tree= fptree(cond_tran,sup,0)
                con_elmts = con_tree.findfqt(fqset)
                if con_elmts is not None:
                    for elmts in con_elmts:
                        ans.append(elmts)
            return ans

    #check if tree hight is larger than 1 
        def checkheight(self):
            if len(list(self.root.lwr_nd.keys()))==0:
                return False
            else:
                return True

    f=open(file_name)   
    n=0
    while f.readline():
        n+=1
    f.close()
    min_sup=math.ceil((x*n)/100)
    f=open(file_name)
    # test_data=list(islice(f,10000))
    # for i in range(len(test_data)):
    #     test_data[i]=list(map(int,test_data[i].split()))
    test_data_file=f
        
    fp_tree = fptree(test_data_file, min_sup,1) #create FP tree on data

    print ("\n========== fpTree mining starts"+" ==========")
    frequentelmtset = fp_tree.findfqt() #mining frequent patt
    w=open(out_name,'w')
    st=['']
    if frequentelmtset:
        for i in frequentelmtset:
            stor=sorted(list(i[0]))
            for j in range(len(stor)):
                if j==len(stor)-1:
                    st[-1]+=str(stor[j])
                else:
                    st[-1]+=str(stor[j])+' '
            st.append('')

        st.sort()
    
    for i in st:
        if i:
            w.write(i)
            w.write('\n')
    