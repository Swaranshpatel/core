
python3 dataT1.py $1 $2 $3 $4